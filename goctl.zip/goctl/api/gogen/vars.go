package gogen

const (
	interval      = "internal/"
	typesPacket   = "types"
	configDir     = interval + "config"
	contextDir    = interval + "svc"
	handlerDir    = interval + "handler"
	logicDir      = interval + "logic"
	middlewareDir = interval + "middleware"
	typesDir      = interval + typesPacket
	groupProperty = "group"
)
