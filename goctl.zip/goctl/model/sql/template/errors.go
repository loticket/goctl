package template

// Error defines an error template
var Error = `package {{.pkg}}

import (
	"github.com/tal-tech/go-zero/core/stores/sqlx"
    "fmt"
	"strings"
)

var ErrNotFound = sqlx.ErrNotFound

type CountNum struct {
	Num int64  {{.numTag}}
}

//条件查询格式化
type WhereVars struct {
	Fields string //字段名称
	Values interface{} //字段的值
	Where  string  //条件
}

func NewWhereVars(field string,values interface{},where string) WhereVars {
	return WhereVars{
		Fields:field, //字段名称
		Values:values, //字段的值
		Where:where,  //条件
	}
}


func FormateVars(wheres []WhereVars) (string,[]interface{}) {
	if len(wheres) == 0{
		return "",[]interface{}{}
	}
	var queryWhere []string = make([]string,0)
	var queryArr []interface{} = make([]interface{},0)
	for _,v := range wheres {
		if v.Where == "&&" {
			queryWhere = append(queryWhere,fmt.Sprintf("%s & ? = ? ",v.Fields))
			queryArr = append(queryArr,v.Values,v.Values)
		} else if v.Where == "like"{
			queryWhere = append(queryWhere,fmt.Sprintf("%s like ?  ",v.Fields))
			queryArr = append(queryArr,v.Values)
		} else {
			queryWhere = append(queryWhere,fmt.Sprintf("%s %s ? ",v.Fields,v.Where))
			queryArr = append(queryArr,v.Values)
		}
	}

	return strings.Join(queryWhere," and "),queryArr
}

`
