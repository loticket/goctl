package template

// FindOne defines find row by id.
var FindList = `
func (m *default{{.upperStartCamelObject}}Model) FindList(where []WhereVars,order string ,page int64,pagesize int64) ([]{{.upperStartCamelObject}}, error) {
	
	var wheres string
	var val []interface{}
	var query string

	if page <= 1 {
		page = 1
	}

	if pagesize <= 1 {
		pagesize = 10
	}

	var offset int64 = (page - 1) * pagesize

	if order == "" {
		order = " {{.originalPrimaryKey}} desc "
	}

	wheres,val = FormateVars(where)
	if wheres != "" && len(val) > 0 {
		query = fmt.Sprintf("select %s from %s where %s order by %s limit %d ,%d ",{{.lowerStartCamelObject}}Rows,m.table,wheres,order,offset,pagesize)
	}else{
		query = fmt.Sprintf("select %s from %s order by %s limit %d ,%d ",{{.lowerStartCamelObject}}Rows,m.table,order,offset,pagesize)
	}
	
	
	{{if .withCache}}

	var resp []{{.upperStartCamelObject}}
    
	var err error = m.QueryRowsNoCache(&resp,query,val...)

	switch err {
	case nil:
		return resp, nil
	case sqlc.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}{{else}}

	var resp []{{.upperStartCamelObject}}

	err := m.conn.QueryRow(&resp,query,val...)

	switch err {
	case nil:
		return resp, nil
	case sqlc.ErrNotFound:
		return nil, ErrNotFound
	default:
		return nil, err
	}{{end}}
}
`

// FindOneMethod defines find row method.
var FindListMethod = `FindList(where []WhereVars,order string ,page int64,pagesize int64) ([]{{.upperStartCamelObject}}, error)`
