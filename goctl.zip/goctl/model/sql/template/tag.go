package template

// Tag defines a tag template text
var Tag = "`db:\"{{.field}}\"`"
