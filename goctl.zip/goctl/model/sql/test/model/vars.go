package model

import "github.com/tal-tech/go-zero/core/stores/sqlx"

// ErrNotFound types an alias for sqlx.ErrNotFound
var ErrNotFound = sqlx.ErrNotFound
