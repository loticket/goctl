package generator

import (
	"fmt"
	"path/filepath"
	"strings"

	"github.com/tal-tech/go-zero/core/collection"
	conf "github.com/tal-tech/go-zero/tools/goctl/config"
	"github.com/tal-tech/go-zero/tools/goctl/rpc/parser"
	"github.com/tal-tech/go-zero/tools/goctl/util"
	"github.com/tal-tech/go-zero/tools/goctl/util/format"
	"github.com/tal-tech/go-zero/tools/goctl/util/stringx"
)

const (
	logicTemplate = `package logic

import (
	"context"

	{{.imports}}

	"github.com/tal-tech/go-zero/core/logx"
)

type {{.logicName}} struct {
	ctx    context.Context
	svcCtx *svc.ServiceContext
	logx.Logger
}

func New{{.logicName}}(ctx context.Context,svcCtx *svc.ServiceContext) *{{.logicName}} {
	return &{{.logicName}}{
		ctx:    ctx,
		svcCtx: svcCtx,
		Logger: logx.WithContext(ctx),
	}
}

{{.functions}}
`
	logicFunctionTemplate = `{{if .hasComment}}{{.comment}}{{end}}
func (l *{{.logicName}}) {{.method}} (in {{.request}}) ({{.response}}, error) {
	// todo: add your logic here and delete this line
	
	return &{{.responseType}}{}, nil
}
`
)

// GenLogic generates the logic file of the rpc service, which corresponds to the RPC definition items in proto.
func (g *DefaultGenerator) GenLogic(ctx DirContext, proto parser.Proto, cfg *conf.Config) error {
	var rpcPaserLogic map[string]LogicFileName = make(map[string]LogicFileName)
	dir := ctx.GetLogic()
	for _, rpc := range proto.Service.RPC {
		var logicName string = parser.CamelCase(rpc.Name) //stringx.From(rpc.Name).ToCamel()
		if strings.Contains(logicName, "_") {
			logicNameArr := strings.Split(logicName, "_")
			logicName = logicNameArr[0]
		}
		logicFilename, err := format.FileNamingFormat(cfg.NamingFormat, logicName+"_logic")
		if err != nil {
			return err
		}

		filename := filepath.Join(dir.Filename, logicFilename+".go")
		functions, err := g.genLogicFunction(proto.PbPackage, rpc)

		if err != nil {
			return err
		}

		imports := collection.NewSet()
		imports.AddStr(fmt.Sprintf(`"%v"`, ctx.GetSvc().Package))
		imports.AddStr(fmt.Sprintf(`"%v"`, ctx.GetPb().Package))
		text, err := util.LoadTemplate(category, logicTemplateFileFile, logicTemplate)
		if err != nil {
			return err
		}

		var namesLogic string = fmt.Sprintf("%sLogic", stringx.From(logicName).ToCamel())
		var importsFile string = strings.Join(imports.KeysStr(), util.NL)
		if info, ok := rpcPaserLogic[namesLogic]; ok {
			var functionNew []string = append(info.Functions, functions)
			rpcPaserLogic[namesLogic] = LogicFileName{
				LogicName:     info.LogicName,
				Imports:       info.Imports,
				LogicTemplate: info.LogicTemplate,
				Filename:      info.Filename,
				Functions:     functionNew,
			}
		} else {
			rpcPaserLogic[namesLogic] = LogicFileName{
				LogicName:     namesLogic,
				Imports:       importsFile,
				LogicTemplate: text,
				Filename:      filename,
				Functions:     []string{functions},
			}
		}

		// err = util.With("logic").GoFmt(true).Parse(text).SaveTo(map[string]interface{}{
		// 	"logicName": fmt.Sprintf("%sLogic", stringx.From(logicName).ToCamel()),
		// 	"functions": functions,
		// 	"imports":   strings.Join(imports.KeysStr(), util.NL),
		// }, filename, false)
		// if err != nil {
		// 	return err
		// }
	}

	for _, info := range rpcPaserLogic {
		err := util.With("logic").GoFmt(true).Parse(info.LogicTemplate).SaveTo(map[string]interface{}{
			"logicName": info.LogicName,
			"functions": strings.Join(info.Functions, " "),
			"imports":   info.Imports,
		}, info.Filename, false)
		if err != nil {
			return err
		}
	}

	return nil
}

func (g *DefaultGenerator) genLogicFunction(goPackage string, rpc *parser.RPC) (string, error) {
	functions := make([]string, 0)
	text, err := util.LoadTemplate(category, logicFuncTemplateFileFile, logicFunctionTemplate)
	if err != nil {
		return "", err
	}

	var logicName string = parser.CamelCase(rpc.Name) //stringx.From(rpc.Name).ToCamel()
	if strings.Contains(logicName, "_") {
		logicNameArr := strings.Split(logicName, "_")
		logicName = logicNameArr[0]
	}

	logicName = stringx.From(logicName + "_logic").ToCamel()
	comment := parser.GetComment(rpc.Doc())
	buffer, err := util.With("fun").Parse(text).Execute(map[string]interface{}{
		"logicName":    logicName,
		"method":       stringx.From(parser.CamelCase(rpc.Name)).ToCamel(),
		"request":      fmt.Sprintf("*%s.%s", goPackage, parser.CamelCase(rpc.RequestType)),
		"response":     fmt.Sprintf("*%s.%s", goPackage, parser.CamelCase(rpc.ReturnsType)),
		"responseType": fmt.Sprintf("%s.%s", goPackage, parser.CamelCase(rpc.ReturnsType)),
		"hasComment":   len(comment) > 0,
		"comment":      comment,
	})
	if err != nil {
		return "", err
	}

	functions = append(functions, buffer.String())
	return strings.Join(functions, util.NL), nil
}

type LogicFileName struct {
	LogicName     string
	Imports       string
	LogicTemplate string
	Filename      string
	Functions     []string
}
