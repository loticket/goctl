package parser

import "github.com/emicklei/proto"

// Import embeds proto.Import
type Import struct {
	*proto.Import
}
