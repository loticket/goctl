package parser

import "github.com/emicklei/proto"

// Package defines the protobuf package.
type Package struct {
	*proto.Package
}
