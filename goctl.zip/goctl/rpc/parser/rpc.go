package parser

import "github.com/emicklei/proto"

// RPC embeds proto.RPC
type RPC struct {
	*proto.RPC
}
