package vars

const (
	// ProjectName the const value of zero
	ProjectName = "zero"
	// ProjectOpenSourceURL the github url of go-zero
	ProjectOpenSourceURL = "github.com/tal-tech/go-zero"
	// OsWindows windows os
	OsWindows = "windows"
	// OsMac mac os
	OsMac = "darwin"
	// OsLinux linux os
	OsLinux = "linux"
)
